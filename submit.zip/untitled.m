clc
clear
n = 200;
a = rand(n,1);
b = rand(1,n);
c = 100 *  a*b;

image(c)
